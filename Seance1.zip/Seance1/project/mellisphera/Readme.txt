
Synthèse du problème :
La détection d'un essaimage est un enjeu important pour les ruches connectés de l'entreprise Mellisphera.
Un essaimage est caractérisé par une hausse de l'activité de la ruche, qui se manifeste par une hausse de la température  àl'intérieur de la ruche. Pour détecter automatiquement ces essaimages, l'entreprise possède un capteur de température interne, qui alerte lorsque la température dans la ruche augmente brusquement. Mais lorsque la température extérieure augmente brusquement, et selon l'orientation de la ruche et l'ensoleillement, les conditions extérieures peuvent faire grimper la température interieure, et donc entraîner des faux positifs dans le mécanisme du capteur de température interne.

Information supplémentaire de l'entreprise :
Les ruches sont souvent équipées d’un capteur de couvain qui fournit la température intérieure ainsi que d’une balance qui en plus du poids (sans intérêt ici) mesure aussi la température extérieure. Ces deux capteurs prennent une mesure toutes les heures mais ne sont pas phasés sur des timestamps identiques. 
Par ailleurs le capteur interne est actif et lorsqu’il détecte un événement thermique il passe d’un échantillonnage horaire à un échantillonnage chaque minute qui surveille le swarmState dans une boucle décisionnelle.

Objectif : Distinguer les essaimages des montée en température extérieure à partir des séries temporelles de température extérieure et interne relevées sur 5 ruches.


Données :
10 fichiers csv issus de 5 ruches (fichier brood et fichier scale) + une présentation powerpoint

Les essaimages se trouvent dans les ruches P1 et L04
Les faux positifs se trouvent dans les ruches R5 et L02.
La colonne swarm_state précise les alertes du capteur.

fichiers brood : swarm_state et temperature interne
fichiers scale : temperature externe

Important : pour chaque ruche, il faudra recaler dans le temps les deux séries temporelles issues des deux fichiers pour construire une série temporelle à deux dimension.