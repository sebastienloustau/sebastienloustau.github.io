L'objectif de ce projet est de développer une plateforme de connaissance à partir du framework web python django.

Le projet consiste à 'copier' l'interface réalisée ici : philoml.org

Avant tout, commencez par vous familiariser avec l'outil django :

Tutoriel django : https://docs.djangoproject.com/fr/4.0/intro/tutorial01/

