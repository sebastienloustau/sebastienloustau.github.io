Synthèse du problème :
L'application philoml.org propose d'afficher une base de données d'extraits de textes philosophiques issus des principaux philosophes de l'histoire de la philosophie. Le site contient plus de 1000 citations qui sont labellisées selon la ou les notions abordées par le philosophe (plus de 60 notions de la philosophie).
L'objectif de ce projet est double:
- construire des vecteurs qui représentent ces citations (feature engineering) à l'aide de techniques de NLP (word counts, tf-idf, word embeddings) pour construire des arbres de décisions pour prédire la notion associé à une citation
- utiliser ces représentations pour créer un moteur de recherche sur les cours de Webdeleuze qui à partir d'une notion ou d'un auteur, pointe vers une moment d'un cours.


Données:
1 fichier json contenant l'ensemble des citations et les labels
230 fichiers json contenant les cours de Webdeleuze
